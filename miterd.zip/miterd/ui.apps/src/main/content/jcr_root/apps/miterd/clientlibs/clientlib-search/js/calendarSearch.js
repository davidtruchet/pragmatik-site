function submitCalendarSearchForm(element) {
	var page = element.dataset.page || "0";
	var form = document.querySelector("form[name='calendar-search']");

	if (form != null && form != undefined) {
		if (form.elements.search != null && form.elements.search != undefined) {
			form.elements.search.value = "true";
		}
		if (form.elements.offset != null && form.elements.offset != undefined) {
			form.elements.offset.value = page;
		}
		form.submit();
	}
}
