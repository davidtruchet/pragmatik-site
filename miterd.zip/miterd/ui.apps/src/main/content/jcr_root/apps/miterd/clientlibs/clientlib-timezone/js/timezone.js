(function ($, document) {
	"use strict";

	function changeDate(fieldName) {
		let dateFields = $("coral-datepicker[name='./" + fieldName + "']");

		dateFields.each((index, field) => {
			let originalValue = $(field).val();

			if (originalValue) {
				let dateObject = new Date(originalValue);
				let formattedDate = dateObject.toISOString();

				if (window.location.href.includes("author")) {
					let utcDate = new Date(
						dateObject.getUTCFullYear(),
						dateObject.getUTCMonth(),
						dateObject.getUTCDate(),
						dateObject.getUTCHours(),
						dateObject.getUTCMinutes(),
						dateObject.getUTCSeconds()
					);

					formattedDate = utcDate.toISOString();
				}

				$(field).val(formattedDate);
			}
		});
	}

	$(document).on("dialog-ready", () => {
		changeDate("startDate");
		changeDate("endDate");
	});
})(Granite.$, document);
