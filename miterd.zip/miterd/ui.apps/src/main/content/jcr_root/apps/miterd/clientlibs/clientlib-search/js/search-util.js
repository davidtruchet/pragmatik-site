function sanitizeHTML(str) {
	const map = {
		'&': '&amp;',
		'<': '&lt;',
		'>': '&gt;',
		'"': '&quot;',
		"'": '&#x27;',
		"/": '&#x2F;',
		"\\": '&#39;',
	};
	const reg = /[&<>"'\/]/ig;
	return str && str.replace(reg, (match)=>(map[match]));
}
