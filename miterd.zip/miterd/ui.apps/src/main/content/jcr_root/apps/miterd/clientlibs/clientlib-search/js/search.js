function submitSearchForm(element) {
	var page = element.dataset.page || "0";
	var form = document.querySelector(".generic-search__container form[name='gsearch']");

	if (form != null && form != undefined) {
		if (form.elements.search != null && form.elements.search != undefined) {
			form.elements.search.value = "true";
		}
		if (form.elements.offset != null && form.elements.offset != undefined) {
			form.elements.offset.value = page;
		}

		form.submit();
	}
}


