(function(document, $) {
    "use strict";

    const ERROR_MESSAGE_SHORT_TITLE = "El título debe tener un mínimo de 3 caracteres.";
    const ERROR_MESSAGE_SHORT_NAME = "El nombre debe tener un mínimo de 3 caracteres o permanecer vacío.";

    $(window).adaptTo("foundation-registry").register("foundation.validation.validator", {
        selector: "[name='pageName']",
        validate: function(el) {
            $(el).val($(el).val().toLowerCase());
            $(el).val($(el).val().replaceAll("_","-"));
        }
    });

    $(window).adaptTo("foundation-registry").register("foundation.validation.validator", {
        selector: "#pastePageDialog input[name=':name']",
        validate: function(el) {
            $(el).val($(el).val().toLowerCase());
            $(el).val($(el).val().replaceAll("_","-"));
        }
    });

    $(window).adaptTo("foundation-registry").register("foundation.validation.validator", {
        selector: ".cq-siteadmin-admin-movepage-rename .rename-item-name",
        validate: function(el) {
            $(el).val($(el).val().toLowerCase());
            $(el).val($(el).val().replaceAll("_","-"));
        }
    });

})(document, Granite.$);
