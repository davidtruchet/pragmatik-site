function submitNewsSearchForm(element) {
	var page = element.dataset.page || "0";
	var form = document.querySelector("form[name='gsearch']");
	var newsDateInput = document.getElementById("newsDate-id-search");
	var resultsPerPageInput = document.getElementById("resultsPerPage-id-search");
	if (newsDateInput === undefined || newsDateInput.value === "") newsDateInput.remove();
	if (resultsPerPageInput === undefined || resultsPerPageInput.value === "") resultsPerPageInput.remove();

	if (form != null && form != undefined) {
		if (form.elements.search != null && form.elements.search != undefined) {
			form.elements.search.value = "true";
		}
		if (form.elements.offset != null && form.elements.offset != undefined) {
			form.elements.offset.value = page;
		}

		form.submit();
	}
}

function submitResultsPerPage(obj) {
	document.getElementById("resultsPerPage-id-search").value = obj.innerHTML;
	var list = document.querySelector("ul.news-search__range").children;

	for (let item of list) {
		item.firstChild.removeAttribute("style");
	}

	obj.classList.add("selected");
	document.querySelector("#btnNewsSearch").click();
}

if (window.location.search != "" &&
	document.querySelector("ul.news-search__range") !== "" &&
	document.querySelector("ul.news-search__range") != undefined) {
	document.addEventListener(
		"DOMContentLoaded",
		() => {
			// Set red color on page results with the query string values
			const params = new URLSearchParams(window.location.search);
			if (params.get("resultsPerPage") != null) {
				var list = document.querySelector("ul.news-search__range").children;
				for (let item of list) {
					if (item.getAttribute("value") === params.get("resultsPerPage")) {
						item.firstChild.classList.add("selected");
					}
				}
			} else {
				document.querySelector("ul.news-search__range li").firstChild.classList.remove("selected");
			}
		},
		false
	);
}
