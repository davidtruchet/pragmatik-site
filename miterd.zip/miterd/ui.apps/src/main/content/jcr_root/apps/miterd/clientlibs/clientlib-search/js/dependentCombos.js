let dependentCombosFlag = "load";

async function getDependentComboTags(elem, dependentComboId, paeasServlet) {
	let multiSelect = elem.parentElement.getElementsByClassName("multiselect-dropdown");
	if (elem && multiSelect && multiSelect.length > 0) {
		let tags = multiSelect[0].getElementsByClassName("checked");
		let dependentCombo = document.getElementById(dependentComboId);

		if (tags && dependentCombo) {
			const selectedTags = [];

			Array.from(tags).forEach((tag) => {
				const elemOptions = elem.options;
				Array.from(elemOptions).forEach((option) => {
					if (option.textContent === tag.getElementsByTagName("label")[0].innerText) {
						selectedTags.push(option.value);
					}
				});
			});

			dependentCombo.innerHTML = "";
			let tagsIds = selectedTags.length > 1 ? selectedTags.join(";") : selectedTags;

			if(paeasServlet) await getPaeasTagsJSON(tagsIds, dependentCombo);
			else await getTagsJSON(tagsIds, dependentCombo, "title", "asc");
		}
	}
}

async function recursiveGetDependentComboTags(combo) {
	let dependentComboId = combo.getAttribute("data-dependent-combo");
	await getDependentComboTags(combo, dependentComboId);
	if(dependentComboId) {
		let dependentCombo = document.getElementById(dependentComboId);
		let dependentComboRelatedId = dependentCombo.getAttribute("data-dependent-combo");
		if(dependentComboRelatedId) {
			await recursiveGetDependentComboTags(dependentCombo);
		}
	}
}

async function getAllCombos(dependentCombos, eventListener) {
	if(dependentCombos) {
		if (dependentCombos.length > 0) {
			dependentCombos.forEach(async (combo) => {
				if(eventListener === "load") {
					await recursiveGetDependentComboTags(combo);
				} else {
					await combo.addEventListener(eventListener, async () => {
						dependentCombosFlag = eventListener;
						await recursiveGetDependentComboTags(combo);
					});
				}
			});
		}
	}
}

window.addEventListener('load', async () => {
	if(document.querySelectorAll(".generic-search__dependent-combo")) {
		const combos = document.querySelectorAll(".generic-search__dependent-combo");
		if (combos.length > 0) {
			await getAllCombos(combos, "load");
			await getAllCombos(combos, "change");
		}
	}
});

async function getTagsJSON(tags, dependentCombo, sortField, sortOrder) {
	if(tags && dependentCombo) {
		const servletUrl = new URL(document.location.origin + "/bin/search/generic.listtags.json");
		servletUrl.searchParams.append("tags", tags);
		let dependentComboId = dependentCombo.getAttribute("id");
		let disabled = false;

		if(sortField) servletUrl.searchParams.append("sortField", sortField);
		if(sortOrder) servletUrl.searchParams.append("sortOrder", sortOrder);

		try {
			const response = await fetch(servletUrl.href, { method: "GET" });
			const result = await response.json();

			if(Object.keys(result).length === 0 && result.constructor === Object) {
				disabled = true;
			} else {
				for (let i in result) {
					dependentCombo.appendChild(createOption(i, result[i], false, false));
				}
			}

			if(dependentCombosFlag === "load") {
				await fillCombo(dependentCombo.getAttribute("name"));
			}

			await reloadMultiSelectCombo(dependentComboId, disabled);
		} catch (error) {
			console.error("Error: ", error);
		}
	}
}

function createOption(value, html, selected, disabled) {
	var opt = document.createElement("option");
	opt.value = value;
	opt.selected = selected;
	opt.disabled = disabled;
	opt.innerHTML = html;
	return opt;
}

async function createDropdownCombo(options, comboId, disabled) {
	if(comboId == undefined && comboId === "") return;

	var config = {
		search: true,
		height: "15rem",
		placeholder: "Seleccione uno o varios elementos",
		txtSelected: "Seleccionados",
		txtAll: "Todo",
		txtRemove: "Eliminar",
		txtSearch: "seleccionar",
		...options,
	};

	function newEl(tag, attrs) {
		var e = document.createElement(tag);
		if (attrs !== undefined) {
			Object.keys(attrs).forEach((k) => {
				if (k === "class") {
					Array.isArray(attrs[k])
						? attrs[k].forEach((o) => o !== "" ? e.classList.add(o) : 0) : attrs[k] !== ""
						? e.classList.add(attrs[k]) : 0;
				} else if (k === "style") {
					Object.keys(attrs[k]).forEach((ks) => {
						e.style[ks] = attrs[k][ks];
					});
				} else if (k === "text") {
					attrs[k] === "" ? (e.innerHTML = "&nbsp;") : (e.innerText = attrs[k]);
				} else if (k === "aria-label") {
					e.setAttribute(k, attrs[k]);
				} else {
					e[k] = attrs[k];
				}
			});
			return e;
		}
	}

	function getNewOption(select, options) {
		for (var i = 0; i < options.length; i++) {
			var opt = new Option();
			opt.innerHTML = select.options[i].innerHTML;
			opt.value = select.options[i].value;
			opt.selected = false;
			options[i] = opt;
		}
		return opt;
	}

	let el = document.getElementById(comboId);
	if(el) {
		const txtSearch = el.getAttribute("data-txtSearch") || config.txtSearch;
		const txtAll = el.getAttribute("data-txtAll") || config.txtAll;
		const txtSelected = el.getAttribute("data-txtSelected") || config.txtSelected;
		const txtRemove = el.getAttribute("data-txtRemove") || config.txtRemove;
		const placeholder = el.getAttribute("data-placeholder") || config.placeholder;

		var div = newEl("div", { class: "multiselect-dropdown" });
		el.style.display = "none";
		el.parentNode.insertBefore(div, el.nextSibling);
		var listWrap = newEl("div", { class: "multiselect-dropdown__list-wrapper" });
		var list = newEl("div", {
			class: "multiselect-dropdown-list",
			style: { height: config.height },
		});
		var search = newEl("input", {
			class: ["multiselect-dropdown-search"].concat([
				config.searchInput?.class ?? "form-control",
			]),
			style: {
				width: "100%",
				display: el.attributes["multiselect-search"]?.value === "true" ? "block" : "none",
			},
			placeholder: txtSearch,
			"aria-label": "input " + txtSearch,
		});

		listWrap.appendChild(search);
		div.appendChild(listWrap);
		listWrap.appendChild(list);

		el.loadOptions = () => {
			list.innerHTML = "";

			if (el.attributes["multiselect-select-all"]?.value == "true") {
				var op = newEl("div", { class: "multiselect-dropdown-all-selector" });
				var ic = newEl("input", {
					type: "checkbox",
					"aria-label": "checkboxgroup " + txtAll,
				});
				op.appendChild(ic);
				op.appendChild(
					newEl("label", {
						text: txtAll,
						"aria-label": "label " + txtAll,
					})
				);

				op.addEventListener("click", () => {
					op.classList.toggle("checked");
					op.querySelector("input").checked =
						!op.querySelector("input").checked;

					var ch = op.querySelector("input").checked;
					list.querySelectorAll(":scope > div:not(.multiselect-dropdown-all-selector)").forEach((i) => {
						if (i.style.display !== "none") {
							i.querySelector("input").checked = ch;
							i.optEl.selected = ch;
						}
					});

					el.dispatchEvent(new Event("change"));
				});
				ic.addEventListener("click", () => {
					ic.checked = !ic.checked;
				});

				list.appendChild(op);
			}

			if (el.options.length > 0 && el.options.selectedIndex == -1) {
				el.options = getNewOption(el, el.options);
			}

			Array.from(el.options).map((o) => {
				var op = newEl("div", {
					class: o.selected ? "checked" : "",
					optEl: o,
				});
				var ic = newEl("input", {
					type: "checkbox",
					checked: o.selected,
					"aria-label": "checkboxgroup " + o.text,
				});
				op.appendChild(ic);
				op.appendChild(
					newEl("label", {
						text: o.text,
						"aria-label": "label " + o.text,
					})
				);

				op.addEventListener("click", () => {
					op.classList.toggle("checked");
					op.querySelector("input").checked =
						!op.querySelector("input").checked;
					op.optEl.selected = !!!op.optEl.selected;
					el.dispatchEvent(new Event("change"));
				});
				ic.addEventListener("click", () => {
					ic.checked = !ic.checked;
				});
				o.listitemEl = op;
				list.appendChild(op);
			});
			div.listEl = listWrap;

			div.refresh = () => {
				div.querySelectorAll("span.optext, span.placeholder").forEach(
					(t) => div.removeChild(t)
				);
				var sels = Array.from(el.selectedOptions);
				if (
					sels.length >
					(el.attributes["multiselect-max-items"]?.value ?? 5)
				) {
					div.appendChild(
						newEl("span", {
							class: ["optext", "maxselected"],
							text: sels.length + " " + txtSelected,
						})
					);
				} else {
					sels.map((x) => {
						var c = newEl("span", {
							class: "optext",
							text: x.text,
							srcOption: x,
						});
						if (
							el.attributes["multiselect-hide-x"]?.value !==
							"true"
						) {
							c.appendChild(
								newEl("span", {
									class: "optdel",
									text: "x",
									title: txtRemove,
									onclick: (ev) => {
										c.srcOption.listitemEl.dispatchEvent(
											new Event("click")
										);
										div.refresh();
										ev.stopPropagation();
									},
								})
							);
						}
						div.appendChild(c);
					});
				}
				if (0 == el.selectedOptions.length) {
					div.appendChild(
						newEl("span", {
							class: "placeholder",
							text:
								el.attributes["placeholder"]?.value ??
								placeholder,
						})
					);
				}
			};
			div.refresh();
		};
		el.loadOptions();

		search.addEventListener("input", () => {
			list.querySelectorAll(":scope div:not(.multiselect-dropdown-all-selector)").forEach((d) => {
				var txt = d.querySelector("label").innerText.toUpperCase();
				d.style.display = txt.includes(search.value.toUpperCase()) ? "flex" : "none";
			});
		});

		div.addEventListener("click", () => {
			listWrap.style.display = "block";
			listWrap.parentElement.classList.add("is-opened");

			search.focus();
			search.select();
			div.refresh();
		});

		document.addEventListener("click", (event) => {
			if (!div.contains(event.target)) {
				listWrap.style.display = "none";
				listWrap.parentElement.classList.remove("is-opened");
				div.refresh();
			}
		});

		document.addEventListener("reset", () => {
			el.parentElement.querySelectorAll("option")
				.forEach((option) => {
					option.selected = option.defaultSelected;
				});

			div.refresh();

			el.parentElement.querySelectorAll(".multiselect-dropdown-list .checked")
				.forEach((dropDownOption) => {
					dropDownOption.classList.remove("checked");
					dropDownOption.querySelector(
						'input[type="checkbox"]'
					).checked = false;
				});

			div.refresh();
		});

		if(!div.parentElement.getElementsByTagName("button")) {
			const closeButton = newEl("button", {
				class: "multiselect-dropdown__close",
				"aria-label": "button " + txtSearch,
			});

			div.parentElement.appendChild(closeButton);

			closeButton.addEventListener("click", function handleClick(event) {
				event.stopPropagation();
				event.preventDefault();

				let listWrapSelected = closeButton.parentElement.querySelector(
					".multiselect-dropdown__list-wrapper"
				).style.display;
				if (listWrapSelected === "none" || listWrapSelected == "") {
					closeButton.parentElement.querySelector(
						".multiselect-dropdown__list-wrapper"
					).style.display = "block";
					closeButton.parentElement
						.querySelector(".multiselect-dropdown")
						.classList.add("is-opened");
				} else {
					closeButton.parentElement.querySelector(
						".multiselect-dropdown__list-wrapper"
					).style.display = "none";
					closeButton.parentElement
						.querySelector(".multiselect-dropdown")
						.classList.remove("is-opened");
				}
			});
		}

		let button = div.parentElement.getElementsByTagName("button");
		if(disabled) {
			div.classList.add("multiselect-dropdown--disabled");
			if(button && button.length  > 0) button[0].setAttribute("disabled", "");
		} else {
			if(button && button.length  > 0) button[0].removeAttribute("disabled");
		}
	}
}

function getSiblingMultiSelectCombo(comboId) {
	let element = document.getElementById(comboId);
	let sibling = element.nextSibling;

	while (sibling && sibling.nodeType !== 1) {
		sibling = sibling.nextSibling;
	}

	if (sibling && sibling.classList.contains("multiselect-dropdown")) {
		return sibling;
	}

	return null;
}

async function reloadMultiSelectCombo(comboId, disabled) {
	let multiselect = getSiblingMultiSelectCombo(comboId);
	if (multiselect !== null) {
		multiselect.remove();
		await createDropdownCombo(window.MultiselectDropdownOptions, comboId, disabled);
	}
}

async function fillCombo(comboName) {
	if (location.href.indexOf("?") < 0) return;

	var formName = "gsearch";
	let url = new URL(window.location.href);
	let params = new URLSearchParams(url.search);

	let list = new Map();
	params.forEach((param, index) => {
		if (list.has(index)) {
			list.set(index, list.get(index).concat(", ", decodeURIComponent(param)));
		} else {
			list.set(index, decodeURIComponent(param));
		}
	});

	let gSearch = eval("document." + formName);
	if (gSearch) {
		list.forEach((param, index) => {
			let element = eval("gSearch." + index);
			if (element) {
				if (index === comboName) {
					Array.from(element.options).filter((option) => {
						if (param.split(", ").includes(option.value)) {
							option.selected = true;
						} else {
							option.selected = false;
						}
					});
				}
			}
		});
	}
}
