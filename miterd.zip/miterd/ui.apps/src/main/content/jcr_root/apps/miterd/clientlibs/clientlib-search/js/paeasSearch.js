window.addEventListener("load", async () => {
	const axisElem = document.getElementById("axis");
	if(axisElem) {
		await getDependentComboTags(axisElem, "action", true);
		axisElem.addEventListener("change", async () => {
			await getDependentComboTags(axisElem, "action", true);
		});
	}
});

async function getPaeasTagsJSON(tags, dependentCombo) {
	const servletUrl = new URL(document.location.origin + "/bin/search/paeas.paeasactions.json");
	servletUrl.searchParams.append("axis", tags);

	try {
		const response = await fetch(servletUrl.href, { method: "GET" });
		const result = await response.json();

		var select = document.getElementById("action");
		for (let i in result) {
			select.appendChild(createOption(i, result[i], false, false));
		}

		await fillCombo(dependentCombo.getAttribute("name"));
		await reloadMultiSelectCombo(dependentCombo.getAttribute("id"));
	} catch (error) {
		console.error("Error: ", error);
	}
}
