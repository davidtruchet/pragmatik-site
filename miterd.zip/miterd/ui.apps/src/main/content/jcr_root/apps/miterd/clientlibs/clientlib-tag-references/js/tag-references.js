(function (window, $) {
	$(window).load(() => {
		if(!window.location.href.includes("tags.html") && !window.location.href.includes("/aem/tags")) return;
		let fui = $(window).adaptTo("foundation-ui");

		let doGetTagReferences = () => {
			$(window).adaptTo("foundation-registry").register("foundation.collection.action.action", {
				name: "miterd.tag.references",
				handler: (name, el, config, collection, selections) => {
					if(selections.length > 0) {
						fui.wait();
						let path = selections[0].getAttribute("data-path");
						const REFERENCES_SERVLET_URL = "/bin/tag.pathreferences.json";
						$.ajax({
							url: REFERENCES_SERVLET_URL,
							type: "GET",
							dataType: "json",
							async: false,
							data: {
								path: path,
								predicate: "wcmcontent",
								exact: true
							},
							success: (result) => {
								fui.clearWait();
								let msg = createElHtml("div");

								if(result.pages.length > 0) {
									let initial = createElHtml("p");
									initial.html("Total <strong>" + result.pages.length + "</strong> referencias para la etiqueta \'<strong>" + path + "</strong>\'");
									initial.appendTo(msg);

									for (let i = 0; i < result.pages.length && i < 10; i++) {
										let a = createElHtml("a");
										a[0].setAttribute("target", "_blank");
										a[0].setAttribute("href", result.pages[i].path);

										let language = "";
										let splitPath = result.pages[i].path.split("/");
										if(result.pages[i].path.includes("language-masters")) {
											language = splitPath.length >= 6 ? splitPath[5] : "";
										} else {
											language = splitPath.length >= 5 ? splitPath[4] : "";
										}

										a.text(result.pages[i].title.substring(0, 100) + (result.pages[i].title.length > 100 ? "..." : ""));
										let p = createElHtml("p");
										p.html("<strong>" + (result.pages[i].path.includes("language-masters") ? "Language-master \'" : "Ubicación \'") + language + "\':</strong> ");
										a.appendTo(p);
										p.appendTo(msg);
									}

									footerMsg = createElHtml("p");
									footerMsg.html("Sólo hemos mostrado las 10 primeras referencias. Si tiene más referencias, haga clic en ver más para ver la lista completa.");
									footerMsg.appendTo(msg);

									fui.prompt("Referencias de la etiqueta", msg.html(), "success", [
										{
											text: "OK",
											primary: true
										},
										{
											text: "Ver más",
											handler: () => window.open(REFERENCES_SERVLET_URL + "?path=" + path + "&predicate=wcmcontent", "_blank")
										},
									]);
								} else {
									let p = createElHtml("p");
									p.html("No hemos encontrado ninguna referencia para la etiqueta \'<strong>" + path + "</strong>\'");
									p.appendTo(msg);

									fui.prompt("Referencias de la etiqueta", msg.html(), "success", [
										{
											text: "OK",
											primary: true
										}
									]);
								}
							},
							error: () => {
								fui.clearWait();
								let msg = "Lo siento, pero hubo un problema al intentar obtener las referencias de la etiqueta."
								fui.prompt("Error", msg, "error", [
									{
										text: "OK",
										warning: true
									}
								]);
							}
						});
					}
				}
			});
		}

		doGetTagReferences();
	});
})(window, Granite.$);
