(function(document, $) {
    const PATH_FIELD_SELECTOR = "public.participation.validate.paths.dam";
    const PATH_NODE_CRX = "/mnt/acs-commons/lists/white-list-assets-public-participation.json";
    const ERROR_MESSAGE_GET_PATHS = "❌ Error al obtener los paths de configuración.";
    const ERROR_MESSAGE_JSON_STRUCTURE = "❌ Error: la estructura del JSON no es válida.";
    const ERROR_MESSAGE_DISCLAIMER = "El fichero debe estar localizado dentro de la carpeta anexos.<br>Revisa el manual de usuario para comprobar las rutas válidas.";
    let tooltipInstance = null; // Variable para almacenar el tooltip
    
    //Funcion para reoger los valores seteados en el nodo del CRX de genericSearch dentro del ACS-COMMONS
    function obtenerPathsConfig(callback) {
        $.get(PATH_NODE_CRX)
            .done(function(data) {
                if (!data.options || !Array.isArray(data.options)) {
                    console.error(ERROR_MESSAGE_JSON_STRUCTURE);
                    callback([]);
                    return;
                }
                // Extraer y limpiar los paths de cada opción
                var allPaths = data.options
                    .map(option => option.value.split(",").map(path => path.trim())) // Dividir por ",", limpiar espacios
                    .flat(); // Aplanar en un solo array
    
                callback(allPaths);
            })
            .fail(function() {
                console.error(ERROR_MESSAGE_GET_PATHS);
                callback([]);
            });
    }

    //Evento para validacion
    foundationReg = $(window).adaptTo("foundation-registry").register("foundation.validation.validator", {
        selector: "[data-foundation-validation='" + PATH_FIELD_SELECTOR + "']",
        validate: function(el) {
            // Obtén el elemento <input> dentro del <foundation-autocomplete>
            var inputElement = $(el).find('input[is="coral-textfield"]')[0];
            if (!inputElement) return;
            
            // Elimina cualquier mensaje de error previo
            $(inputElement).closest(".coral-Form-fieldwrapper").find(".error-message").remove();
            $(inputElement).css("border-color", "");

            obtenerPathsConfig(function(pathsConfig) {
                var isMatch = pathsConfig.some(path => inputElement.value.startsWith(path + "/") || inputElement.value === path);

                if (!isMatch) {
                    inputElement.setCustomValidity(ERROR_MESSAGE_DISCLAIMER);
                    $(inputElement).css("border-color", "red");

                    // Elimina tooltip anterior si existe
                    if (tooltipInstance) {
                        tooltipInstance.remove();
                        tooltipInstance = null;
                    }

                    // Crear y mostrar nuevo tooltip
                    tooltipInstance = new Coral.Tooltip().set({
                        content: {
                            innerHTML: ERROR_MESSAGE_DISCLAIMER
                        },
                        target: inputElement,
                        placement: "bottom",
                        variant: "error"
                    });

                    $(inputElement).closest(".coral-Form-fieldwrapper").append(tooltipInstance);

                } else {
                    // Si es válido, elimina el tooltip si existe y restablece estilos
                    inputElement.setCustomValidity("");
                    $(inputElement).css("border-color", "");

                    if (tooltipInstance) {
                        tooltipInstance.remove();
                        tooltipInstance = null;
                    }
                }
            });
        }
    });
}(document, Granite.$));
