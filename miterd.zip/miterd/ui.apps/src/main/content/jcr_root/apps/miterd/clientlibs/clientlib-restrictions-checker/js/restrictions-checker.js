(function (window, document, $, Granite) {
	// The action button "Publish" should never appear if the selected page is a children of "/content/*/language-masters"
	// The action button "Edit, Copy, Move, Delete, Paste, Create Page, Create Site" should never appear if the selected page is a children of "/content/*/es"
	// Action Delete custom with a warning msg
	$(window).load(() => {
		if(!window.location.href.includes("sites.html")) return;

		let userGroups = isAllowedUser();
		let managePublicationButton = ".cq-siteadmin-admin-actions-publish-activator",
			quickPublishButton = ".cq-siteadmin-admin-actions-quickpublish-activator",
			editButton = ".cq-siteadmin-admin-actions-edit-activator",
			copyButton = ".cq-siteadmin-admin-actions-copy-activator",
			moveButton = ".cq-siteadmin-admin-actions-move-activator",
			deleteButton = ".cq-siteadmin-admin-actions-delete-activator",
			createPageButton = ".cq-siteadmin-admin-createpage.coral3-AnchorList-item",
			createSiteButton = ".cq-siteadmin-admin-createsite.coral3-AnchorList-item",
			pathAttribute = "data-granite-collection-item-id",
			pasteButton = ".cq-siteadmin-admin-pastepage.coral-Button--graniteActionBar",
			pasteLink = ".cq-siteadmin-admin-pastepage.coral-Link",
			atLeastOnePageSelectedHasLiveCopies = false,
			doOnSelectionChange = async (whichSelector) => {
				$(whichSelector).filter((index, page) => {
					let regexPatternLM = /\/content\/[^/]+?\/language-masters/gi;
					let regexPattern = /\/content\/[^/]+?\/es/gi;
					let rootLM = /^\/content\/[^/]+?\/language-masters\/?$/;
					let rootLMLang = /^\/content\/[^/]+\/language-masters\/[^/]+$/;
					let path = page.getAttribute(pathAttribute);

					if (!page.selected) return;

					if (regexPattern.test(path)) {
						$(managePublicationButton).parent().show();
						$(quickPublishButton).parent().show();
						$(editButton).parent().hide();
						$(copyButton).parent().hide();
						$(moveButton).parent().hide();
						$(deleteButton).parent().hide();
						$(createPageButton).hide();
						$(createSiteButton).hide();
						$(pasteButton).hide();
						$(pasteLink).hide();
					}

					if (regexPatternLM.test(path)) {
						$(managePublicationButton).parent().hide();
						$(quickPublishButton).parent().hide();
						$(editButton).parent().show();
						$(createPageButton).css('display', 'block');
						$(createSiteButton).css('display', 'block');
						if (rootLM.test(path) || rootLMLang.test(path)) {
							$(copyButton).parent().hide();
							$(moveButton).parent().hide();
							$(deleteButton).parent().hide();
							$(pasteButton).hide();
							$(pasteLink).hide();
						} else {
							$(copyButton).parent().show();
							$(moveButton).parent().show();
							$(deleteButton).parent().show();
							$(pasteButton).show();
							$(pasteLink).show();
						}

						let hasLMLiveCopies = getLiveCopies(path, "ca=true&gl=true&eu=true&va=true&en=true&fr=true&pt=true");
						let hasESLiveCopies = getLiveCopies(
							path.replace("/language-masters/", "/es/"), "es=true&ca=true&gl=true&eu=true&va=true&en=true&fr=true&pt=true");
						if(hasLMLiveCopies || hasESLiveCopies) {
							atLeastOnePageSelectedHasLiveCopies = true;
						}
					}
				});
			},
			doOnCollectionNavigate = (path) => {
				let regexPatternLM = /\/content\/[^/]+?\/language-masters/gi;
				let regexPattern = /\/content\/[^/]+?\/es/gi;

				if (regexPattern.test(path)) {
					$(pasteButton).hide();
					$(pasteLink).hide();
					$(createPageButton).hide();
					$(createSiteButton).hide();
				}

				if (regexPatternLM.test(path)) {
					$(pasteButton).show();
					$(pasteLink).show();
					$(createPageButton).css('display', 'block');
					$(createSiteButton).css('display', 'block');
				}
			},
			doDeleteCheckerRegistry = () => {
				let fui = $(window).adaptTo("foundation-ui");
				$(window).adaptTo("foundation-registry").register("foundation.collection.action.action", {
					name: "cq.wcm.delete",
					handler: function(name, el, config, collection, selections) {
						if (!userGroups) {
							if (atLeastOnePageSelectedHasLiveCopies) {
								fui.prompt(getDeleteText(), getEditorDeleteMsg(), "error", [
									{
										text: "OK",
										warning: true
									}
								]);
							} else {
								archivePages(name, el, config, collection, selections);
							}
						} else {
							if (atLeastOnePageSelectedHasLiveCopies) {
								fui.prompt(getDeleteText(), getPublisherDeleteMsg(), "error", [
									{
										text: "CANCELAR"
									},
									{
										text: "OK",
										warning: true,
										handler: () => archivePages(name, el, config, collection, selections),
									}
								]);
							} else {
								archivePages(name, el, config, collection, selections);
							}
						}
					}
				});
			}

		$(document).on("foundation-selections-change", async (e) => {
			atLeastOnePageSelectedHasLiveCopies = false;

			switch (e.target.tagName) {
				case "CORAL-MASONRY":
					await doOnSelectionChange("coral-masonry-item");
					doDeleteCheckerRegistry();
					break;
				case "CORAL-COLUMNVIEW":
					await doOnSelectionChange("coral-columnview-item");
					doDeleteCheckerRegistry();
					break;
				case "TABLE":
					await doOnSelectionChange("tr.foundation-collection-item");
					doDeleteCheckerRegistry();
					break;
				default:
					return;
			}
		});

		$(document).on("foundation-collection-navigate", (e) => {
			let path = e.target.getAttribute("data-foundation-collection-id");
			doOnCollectionNavigate(path);
		});

		// Adobe Code (Delete Button functions in wcm.min.js)
		var COMMAND_URL = Granite.HTTP.externalize("/bin/wcmcommand");
		var preArchiveValue = true;

		var deleteText;
		function getDeleteText() {
			if (!deleteText) deleteText = Granite.I18n.get("Delete");
			return deleteText;
		}

		var cancelText;
		function getCancelText() {
			if (!cancelText) cancelText = Granite.I18n.get("Cancel");
			return cancelText;
		}

		function deletePages(collection, paths, force, checkChildren, bulkDeleteData, archive) {
			var ui = $(window).adaptTo("foundation-ui");
			ui.wait();
			var url = COMMAND_URL;
			var data = {
				_charset_: "UTF-8",
				force: !!force,
				checkChildren: !!checkChildren,
				archive: !!archive,
			};
			if (bulkDeleteData) {
				url = bulkDeleteData.sourceParentPath + ".bulkpages.delete";
				Object.assign(data, bulkDeleteData);
			} else {
				data.cmd = "deletePage";
				data.path = paths;
			}
			$.ajax({
				url: url,
				type: "POST",
				data: data,
				success: function () {
					ui.clearWait();
					var api = collection.adaptTo("foundation-collection");
					var layoutConfig = collection.data("foundationLayout");
					if (layoutConfig && layoutConfig.layoutId === "column") {
						var previewShown = $("coral-columnview-preview").length > 0;
						if (previewShown)
							if (api && "load" in api) {
								var id = paths[0];
								if (id) {
									var parentId = id.substring(0, id.lastIndexOf("/")) || "";
									if (parentId !== "") api.load(parentId);
								}
							}
						Coral.commons.nextFrame(function () {
							if (api && "reload" in api) api.reload();
						});
						return;
					}
					if (api && "reload" in api) {
						api.reload();
						return;
					}
					var contentApi = $(".foundation-content").adaptTo("foundation-content");
					if (contentApi) contentApi.refresh();
				},
				error: function (xhr) {
					ui.clearWait();
					var message = Granite.I18n.getVar($(xhr.responseText).find("#Message")).html();
					if (xhr.status === 412) {
						ui.prompt(getDeleteText(), message, "notice", [
							{
								text: getCancelText(),
							},
							{
								text: Granite.I18n.get("Force Delete"),
								warning: true,
								handler: function () {
									deletePages(collection, paths, true, false, bulkDeleteData, preArchiveValue);
								},
							},
						]);
						return;
					}
					ui.alert(Granite.I18n.get("Error"), message, "error");
				},
			});
		}

		function createEl(name) {
			return $(document.createElement(name));
		}

		function getBulkDeleteData(config, collection) {
			var bulkDeleteData;
			var exceptPath = [];
			if (config && config.activeSelectionCount === "bulk")
				if (collection && collection.dataset.foundationSelectionsSelectallMode === "true") {
					var $collection = $(collection);
					var paginationAPI = $collection.adaptTo("foundation-collection").getPagination();
					if (paginationAPI && paginationAPI.hasNext) {
						$collection
							.find(".foundation-collection-item:not(.foundation-selections-item)")
							.each(function () {
								var itemPath = this.dataset.foundationCollectionItemId;
								if (itemPath) exceptPath.push(itemPath);
							});
						bulkDeleteData = {
							sourceParentPath: collection.dataset.foundationCollectionId,
							exceptPath: exceptPath,
						};
					}
				}
			return bulkDeleteData;
		}

		function archivePages(name, el, config, collection, selections) {
			var bulkDeleteData = getBulkDeleteData(config, collection);
			var message = createEl("div");
			var intro = createEl("p").appendTo(message);
			if (selections.length === 1)
				intro.text(Granite.I18n.get("You are going to delete the following item:"));
			else if (bulkDeleteData)
				intro.text(
					Granite.I18n.get(
						"You are going to delete all items from {0} path:",
						bulkDeleteData.sourceParentPath
					)
				);
			else
				intro.text(
					Granite.I18n.get("You are going to delete the following {0} items:", selections.length)
				);
			var list = [];
			var maxCount = Math.min(selections.length, 12);
			for (var i = 0, ln = maxCount; i < ln; i++) {
				var title = $(selections[i]).find(".foundation-collection-item-title").text();
				list.push(createEl("b").text(title).prop("outerHTML"));
			}
			if (selections.length > maxCount) list.push("\x26#8230;");
			createEl("p").html(list.join("\x3cbr\x3e")).appendTo(message);
			var archive = createEl("coral-checkbox");
			archive.attr("checked", true);
			archive.attr("name", "archive");
			archive.text(Granite.I18n.get("Do you want to archive pages before deletion? "));
			archive.appendTo(message);
			var icon = createEl("coral-icon");
			icon.attr("icon", "infoCircle").appendTo(message);
			var toolTip = createEl("coral-tooltip");
			toolTip.attr("target", "_prev");
			toolTip.attr("placement", "left");
			toolTip.attr("variant", "info");
			toolTip.attr("role", "tooltip");
			toolTip.attr("interaction", "on");
			toolTip.text(
				Granite.I18n.get(
					"Archiving pages on deletion allows restoring pages from, i.e. undoing, delete operation."
				)
			);
			toolTip.appendTo(message);
			var ui = $(window).adaptTo("foundation-ui");
			ui.prompt(getDeleteText(), message.html(), "notice", [
				{
					text: getCancelText(),
				},
				{
					text: getDeleteText(),
					warning: true,
					handler: function () {
						var archiveValue = $(document.body).find("coral-checkbox[name\x3d'archive']")[0]
							.checked;
						preArchiveValue = archiveValue;
						var paths = selections.map(function (v) {
							return $(v).data("foundationCollectionItemId");
						});
						deletePages($(collection), paths, false, true, bulkDeleteData, archiveValue);
					},
				},
			]);
		}
	});
})(window, document, Granite.$, Granite);
