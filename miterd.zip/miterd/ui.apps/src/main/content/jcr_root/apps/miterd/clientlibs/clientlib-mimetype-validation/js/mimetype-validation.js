(function(Granite, $) {
    "use strict";
	var VIDEO_SELECTOR = "miterd.mimetype.video.validator";
	var AUDIO_SELECTOR = "miterd.mimetype.audio.validator";

    $(window).adaptTo("foundation-registry").register("foundation.validation.validator", {
        selector: "[data-foundation-validation='" + VIDEO_SELECTOR + "']",
        validate: (el) => {
            var regexPattern = /(.+)[.](mp4|m4v|mpeg|mov|avi|wmv|webm|avchd|flv|swf|ogg)$/ig;
            var errorMessage = Granite.I18n.get("Only video mimetypes are allowed in this field! Example: *.mp4, *.wmv, *.flv...");
            var result = el.value.match(regexPattern);

            if (result === null) {
                return errorMessage;
            }
        }
    });

    $(window).adaptTo("foundation-registry").register("foundation.validation.validator", {
        selector: "[data-foundation-validation='" + AUDIO_SELECTOR + "']",
        validate: (el) => {
            var regexPattern = /(.+)[.](mp3|ogg)$/ig;
            var errorMessage = Granite.I18n.get("Only audio mimetypes are allowed in this field! Example: *.mp3...");
            var result = el.value.match(regexPattern);

            if (result === null) {
                return errorMessage;
            }
        }
    });
})(Granite, Granite.$);


