(function () {
	const path = window.location.pathname;
	const languagePattern = /(?:\/[^/]*)?\/content\/[^/]+?\/(?:[^/]{2}|language-masters)\/([^/]{2})(?:\/|[.]html).*|^\/([^/]{2})(?:\/|[.]html).*/i;
	const languageMatch = path.match(languagePattern);
	const list = document.querySelectorAll(".languagenavigation ul.dropdown-menu li a");
	const changeButton = (item) => {
		document.querySelector(".languagenavigation button#dropdownMenuButton1").textContent = item.textContent.trim();
		item.style.display = "none";
	}
	if (list) {
		const language = languageMatch ? (languageMatch[1] || languageMatch[2]) : "es";

		list.forEach((item) => {
			if (item.text.trim() === "Valencià") {
				item.lang = "va";
				item.hreflang = "va";

				if (language === "va") changeButton(item);
			} else {
				if (item.lang === language) {
					changeButton(item);
				} else {
					item.style.display = "block";
				}
			}

			let link = /^\/content/.test(path) ?
				path.replace(/^(?:\/[^/])*(\/content\/[^/]+\/[^/]+\/)[^/]{2}((?:\/|[.]html).*)$/i, `$1${item.lang}$2`) :
				path.replace(/^\/[^/]{2}((?:\/|[.]html).*)$/i, `/${item.lang}$1`)
			item.href = path === "/" || /^\/conf/.test(path) || /^\/content\/experience-fragments/.test(path) ? `/${item.lang}.html` : link;
        });
	}
})();
