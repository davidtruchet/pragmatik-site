
let allowedGroups = [
		"standard-publishers",
		"standard-editors-publishers",
		"standard-content-validators",
		"standard-content-admins",
		"standard-aem-devs",
		"administrators",
		"development-team",
	],
	allowedUserIDs = ["admin", "customer-admin"];

function createElHtml(name) {
	return $(document.createElement(name))
}

function getLiveCopies(path, languagesQueryString) {
	let hasLiveCopies = false;

	$.ajax({
		url: path + ".includelanguagecopies.json?" + languagesQueryString,
		async: false,
	}).done(handler);

	function handler(data) {
		if (!data || !data.total) {
			return;
		}

		hasLiveCopies = data.total > 0;
	}

	return hasLiveCopies;
}

function isAllowedUser() {
	let isAllowedUser = false;

	$.ajax({
		url: "/bin/author.usergroups.json",
		async: false,
	}).done(handler);

	function handler(data) {
		if (!data || !data.allowedGroup) {
			return;
		}

		isAllowedUser = data.allowedGroup;
	}

	return isAllowedUser;
}

function getEditorDeleteMsg() {
	let message = createElHtml("div");
	let p1 = createElHtml("p");
	p1.html(
		'La acción de <strong>“Borrar” NO ESTÁ DISPONIBLE</strong> debido a que la página/s tiene generadas live-copies y usted solo dispone de permisos de <strong>Edición</strong>.'
	);
	p1.appendTo(message);
	let p2 = createElHtml("p");
	p2.html(
		"Por favor, contacte con un usuario de su sección con permisos de <strong>Publicación</strong> para poder llevar a cabo la acción."
	);
	p2.appendTo(message);
	return message.html();
}

function getPublisherDeleteMsg() {
	let message = createElHtml("div");
	let p1 = createElHtml("p");
	p1.html(
		'La página/s seleccionada tiene generadas live-copies. Antes de llevar a cabo su correcta eliminación, debe revisar los siguientes puntos:'
	);
	p1.appendTo(message);
	let p2 = createElHtml("p");
	p2.html(
		"<strong>A)</strong> La página/s debe estar despublicada previamente en todos los idiomas."
	);
	p2.appendTo(message);
	let p3 = createElHtml("p");
	p3.html(
		"<strong>B)</strong> Debe comprobar que la página/s no tiene referencias a otras páginas que puedan verse afectadas."
	);
	p3.appendTo(message);
	let p4 = createElHtml("p");
	p4.html(
		"En caso de duda puede consultar el apartado correspondiente en el manual de usuario para más información."
	);
	p4.appendTo(message);
	return message.html();
}

function getEditorMoveMsg() {
	let message = createElHtml("div");
	let p1 = createElHtml("p");
	p1.html(
		'La acción de <strong>"Mover" NO ESTA DISPONIBLE</strong> debido a que la página tiene generadas live-copies y usted solo dispone de permisos de <strong>Edición</strong>.'
	);
	p1.appendTo(message);
	let p2 = createElHtml("p");
	p2.html(
		"Por favor, contacte con un usuario de su sección con permisos de <strong>Publicación</strong> para poder llevar a cabo la acción."
	);
	p2.appendTo(message);
	return message.html();
}

function getPublisherMoveMsg() {
	let message = createElHtml("div");
	let p1 = createElHtml("p");
	p1.html(
		'La acción de <strong>"Mover" NO ESTA DISPONIBLE</strong> debido a que la página tiene generadas live-copies.'
	);
	p1.appendTo(message);
	let p2 = createElHtml("p");
	p2.html(
		"Para poder llevar a cabo esta acción, consulte el apartado <strong>'Cómo mover una página con roll-out generado'</strong> del manual de usuario."
	);
	p2.appendTo(message);
	let p3 = createElHtml("p");
	p3.html(
		"Si lo que desea es cambiar la url, consulte <strong>'Cómo cambiar la URL de una página con roll-out generado'</strong>."
	);
	p3.appendTo(message);
	return message.html();
}
