(function ($) {
	CF_BASEPATH = '/content/dam/fototeca/';
	let config = {};

	config.form = document.querySelector('.content-fragment-editor');

    if ((CF_BASEPATH.length > 0
        && config.form.dataset.fragment.indexOf(CF_BASEPATH) === -1)) {
        return;
    }

	document.addEventListener("DOMContentLoaded", () => {
		const allDisableFields = ["codigo", "codtem1", "codtem2", "codtem3", "id"];
		const taxonDisableFields = ["idtaxon", "scientificname", "ncientifico",
		"codnombreci", "idorder", "ordern", "idfamily", "family", "idgenus",
		"genus", "idspecificepithet", "specificepithet", "idinfraspecificepithet",
		"infraspecificepithet", "castellano", "catalan", "euskera", "gallego"];
		const otherSpeciesDisableFields = ["idtaxon", "codnombreci", "idorder",
		"ordern", "idfamily", "idgenus", "genus", "idspecificepithet",
		"specificepithet", "idinfraspecificepithet", "infraspecificepithet", "catalan",
		"euskera", "gallego"];

		let inputs = document.querySelectorAll("input.coral-Form-field");

		inputs.forEach((element) => {
			if(window.location.pathname.includes("/taxon") &&
				taxonDisableFields.includes(element.getAttribute("data-element"))) {
				element.setAttribute("disabled", true);
			} else if(window.location.pathname.includes("species/") &&
				otherSpeciesDisableFields.includes(element.getAttribute("data-element"))) {
				element.setAttribute("disabled", true);
			} else if(allDisableFields.includes(element.getAttribute("data-element"))) {
				element.setAttribute("disabled", true);
			};
		});
	});
}(Granite.$));
