function submitFototecaSearchForm(element) {
	var page = element.dataset.page || "0";
	var form = document.querySelector("form[name='gsearch']");

	if (form != null && form != undefined) {
		if (form.elements.offset != null && form.elements.offset != undefined) {
			form.elements.offset.value = page;
		}
		form.submit();
	}
}

window.addEventListener('load', function() {
	var radioButtons = document.querySelectorAll("form[name='gsearch'] input[type='radio'][name='view']");
	if(radioButtons.length>0){
		// Check if any radio button is already checked
		var anyChecked = Array.from(radioButtons).some(function(radio) {
			return radio.checked;
		});

		// If none are checked, mark the first one as checked
		if (!anyChecked) {
			radioButtons[0].checked = true;
		}
	}

	if(isVideoGallery()){
		var prev = document.querySelector("#tb-images button[data-controls='prev']");
		var next = document.querySelector("#tb-images button[data-controls='next']");

		if(prev){
			prev.addEventListener('click', prevButtonHandler);
		}

		if(next){
			next.addEventListener('click', nextButtonHandler);
		}
    }
});

function handleCarouselControl(operation){
	var idx = getThumbIndex();
	if(idx > -1){
		if(operation == "next"){
			createIframe(idx+1);
		}
		if(operation == "prev"){
			createIframe(idx-1);
		}
	}
}

// Function to get the thumb index
function getThumbIndex(){
	var thumbItems = document.querySelectorAll('.gallery__thumb-item');
	var selectedIndex = -1;
	if(thumbItems.length>0){
		for (var i = 0; i < thumbItems.length; i++) {
			if (thumbItems[i].classList.contains('selected')) {
				selectedIndex = i;
				break;
			}
		}
	}
	return selectedIndex;
}

function createIframe(idx){
	var videoData = document.querySelectorAll("#tb-images div.gallery__footer img.video-data");
	if(videoData.length>0){
		var iframe = document.createElement('iframe');
		// Set attributes for the iframe
		iframe.title = videoData[idx].getAttribute("data-title");
		iframe.width = "100%";
		iframe.height = 500;
		iframe.src = videoData[idx].getAttribute("data-src");
		iframe.frameBorder = 0;
		iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen";
		iframe.ariaLabel = videoData[idx].getAttribute("data-title");

		//	remove old iframe
		document.querySelector("#tb-images div.video-media iframe").remove();
		// add new iframe
		document.querySelectorAll("#tb-images div.video-media")[idx].appendChild(iframe);
	}
}

function prevButtonHandler() {
	handleCarouselControl('prev');
}

function nextButtonHandler() {
	handleCarouselControl('next');
}

function isVideoGallery(){
	return document.querySelectorAll("#tb-images div.video-media").length > 0;
}

function handleGalleryItemClick(event){
	if(isVideoGallery()){
		var clickedItem = event.target;
		var idx = clickedItem.parentElement.parentElement.parentElement.getAttribute("data-thumb");
		createIframe(idx);
	}
}
