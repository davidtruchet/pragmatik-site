(function ($) {
	$(window).load((e) => {
		e.preventDefault();
		let fui = $(window).adaptTo("foundation-ui");
		fui.wait();

		let movePagePath = "";
		if(window.location.href.includes("movepagewizard")) {
			movePagePath = window.location.href.split(".html")[1];
		} else return;

		let userGroups = isAllowedUser();
		let hasLMLiveCopies = getLiveCopies(movePagePath, "ca=true&gl=true&eu=true&va=true&en=true&fr=true&pt=true");
		let hasESLiveCopies = getLiveCopies(
			movePagePath.replace("/language-masters/", "/es/"), "es=true&ca=true&gl=true&eu=true&va=true&en=true&fr=true&pt=true");

		if (!userGroups) {
			if(hasLMLiveCopies || hasESLiveCopies) {
				fui.clearWait();
				fui.prompt("Mover", getEditorMoveMsg(), "error", [
					{
						text: "OK",
						warning: true,
						handler: () => history.back(),
					},
				]);
				return;
			}
		} else {
			if(hasLMLiveCopies || hasESLiveCopies) {
				fui.clearWait();
				fui.prompt("Mover", getPublisherMoveMsg(), "error", [
					{
						text: "OK",
						warning: true,
						handler: () => history.back(),
					},
				]);
				return;
			}
		}

		fui.clearWait();
	});
})(Granite.$);
